package com.ads.smartcard.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "contacts")
public class Contact implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String RequestorNidno;
    private String Requestorname;
    private String RequestorPinno;
    private String Refname;
    private String Reqdate;
    public String workupdate;
    public String remarks;
    public Contact() {
    }

    @Ignore
    public Contact(int id, String RequestorNidno1,String Requestorname1,String RequestorPinno1, String Refname1,String Reqdate1,String workupdate1,String remarks1) {
        this.id = id;
        this.RequestorNidno = RequestorNidno1;
        this.Requestorname=Requestorname1;

        this.RequestorPinno = RequestorPinno1;
        this.Refname = Refname1;
        this.Reqdate = Reqdate1;
        this.workupdate =workupdate1;
        this.remarks = remarks1;

    }


    protected Contact(Parcel in) {
        id = in.readInt();
        RequestorNidno= in.readString();
        Requestorname=in.readString();

        RequestorPinno = in.readString();
        Refname = in.readString();
        Reqdate = in.readString();
        workupdate =in.readString();
        remarks = in.readString();


    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override
        public Contact createFromParcel(Parcel in) {
            return new Contact(in);
        }

        @Override
        public Contact[] newArray(int size) {
            return new Contact[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getRequestorNidno1() {
        return RequestorNidno;
    }

    public String getRequestorname1() {
        return Requestorname;
    }

    public String getRequestorPinno1() {
        return RequestorPinno;
    }
    public String getRefname1() {
        return Refname;
    }
    public String getReqdate1() {
        return Reqdate;
    }
    public String getworkupdate1() {
        return workupdate;
    }

    public String getremarks1() {
        return remarks;
    }
    public void setRequestorNidno1(String RequestorNidno) {
        this.RequestorNidno = RequestorNidno;
    }
    public void setRequestorname1(String Requestorname) {
        this.Requestorname = Requestorname;
    }
    public void setRequestorPinno1(String RequestorPinno) {
        this.RequestorPinno = RequestorPinno;
    }
    public void setRefname1(String Refname) {
        this.Refname = Refname;
    }
    public void setReqdate1(String Reqdate) {
        this.Reqdate = Reqdate;
    }
    public void setworkupdate1(String workupdate) {
        this.workupdate = workupdate;
    }
    public void setremarks1(String remarks) {
        this.remarks = remarks;
    }

    public String getRequestorNidno() {
        return RequestorNidno;
    }

    public void setRequestorNidno(String RequestorNidno) {
        this.RequestorNidno = RequestorNidno;
    }






    public String getRequestorname() {
        return Requestorname;
    }

    public void setRequestorname(String Requestorname) {
        this.Requestorname = Requestorname;
    }

    public String getRequestorPinno() {
        return RequestorPinno;
    }

    public void setRequestorPinno(String RequestorPinno) {
        this.RequestorPinno = RequestorPinno;
    }

    public String getRefname() {
        return Refname;
    }

    public void setRefname(String Refname) {
        this.Refname = Refname;
    }


    public String getReqdate() {
        return Reqdate;
    }

    public void setReqdate(String Reqdate) {
        this.Reqdate = Reqdate;
    }

    public String getworkupdate() {
        return workupdate;
    }

    public void setworkupdate(String workupdate) {
        this.workupdate = workupdate;
    }

    public String getremarks() {
        return remarks;
    }

    public void setremarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "Contact{" +
                "id=" + id +
                ", RequestorNidno='" + RequestorNidno + '\'' +
                ", RequestorName='" + Requestorname + '\'' +

                ", RequestorPinno='" + RequestorPinno + '\'' +

                ", Refname='" + Refname + '\'' +
                ", Reqdate='" + Reqdate + '\'' +
                ", workupdate='" + workupdate + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);

        parcel.writeString(RequestorNidno);
        parcel.writeString(Requestorname);
        parcel.writeString(RequestorPinno );
        parcel.writeString(Refname);
        parcel.writeString(Reqdate);
        parcel.writeString(workupdate);
        parcel.writeString(remarks);
    }
}
