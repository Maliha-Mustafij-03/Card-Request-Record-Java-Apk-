package com.ads.smartcard;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ads.smartcard.model.Contact;
import com.ads.smartcard.viewmodel.ContactViewModel;


public class EditContactActivity extends AppCompatActivity {

    private Contact contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);

        // **
        contact = getIntent().getParcelableExtra("contact");

        // **
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_white_24dp);

        // **
        EditText RequesterNino1 = findViewById(R.id.editText1);
        EditText Questionnaire1 = findViewById(R.id.editText2);
        EditText RequestPino1 = findViewById(R.id.editText3);
        EditText ref = findViewById(R.id.edit);
        EditText date1 = findViewById(R.id.edit2);
        EditText work = findViewById(R.id.edit4);

        EditText remarks1 = findViewById(R.id.edit5);

        RequesterNino1.setText(contact.getRequestorNidno());
        Questionnaire1.setText(contact.getRequestorname());
        RequestPino1.setText(contact.getRequestorPinno());
        ref.setText(contact.getRefname());
        date1.setText(contact.getReqdate());
        work.setText(contact.getworkupdate());
        remarks1.setText(contact.getremarks());



        // **

    }

    private void updateContactInDb() {
        EditText RequesterNino1 = findViewById(R.id.editText1);
        EditText Questionnaire1 = findViewById(R.id.editText2);
        EditText RequestPino1 = findViewById(R.id.editText3);
        EditText ref = findViewById(R.id.edit);
        EditText date1 = findViewById(R.id.edit2);
        EditText work1 = findViewById(R.id.edit4);

        EditText remarks1 = findViewById(R.id.edit5);
        // **
        String RequesterNino = RequesterNino1.getText().toString();
        String Questionnaire = Questionnaire1.getText().toString();
        String RequestPino = RequestPino1.getText().toString();
        String Rename = ref.getText().toString();
        String Requited = date1.getText().toString();
        String work = work1.getText().toString();
        String remarks = remarks1.getText().toString();
        // **

        contact.setRequestorNidno(RequesterNino);
        contact.setRequestorname(Questionnaire);
        contact.setRequestorPinno(RequestPino);
        contact.setRefname(Rename);
        contact.setReqdate(Requited);
       contact.setworkupdate(work);
        contact.setremarks(remarks);

        if (Questionnaire.isEmpty() ||Rename.isEmpty()){
            Toast.makeText(this, "Please insert data in all required fields!", Toast.LENGTH_SHORT).show();
        }
        else {
            // **
            ContactViewModel contactViewModel = new ViewModelProvider(EditContactActivity.this).get(ContactViewModel.class);
            contactViewModel.update(contact);
            // **
            Toast.makeText(this, " Record updated!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(EditContactActivity.this,MainActivity.class));
            finish();
        }
    }

    // ActionBar Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_contact_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_save) {
            // **
            updateContactInDb();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
