package com.ads.smartcard;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ads.smartcard.model.Contact;
import com.ads.smartcard.viewmodel.ContactViewModel;

public class AddContactActivity extends AppCompatActivity {

    private ContactViewModel contactViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        // **
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_white_24dp);
    }

    private void addContactToDb() {
        EditText RequestorNidnoEditText = findViewById(R.id.editText1);
        EditText RequestornameEditText = findViewById(R.id.editText2);
        EditText RequestorPinnoEditText = findViewById(R.id.editText3);
        EditText RefnameEditText = findViewById(R.id.edit);
        EditText ReqdateEditText = findViewById(R.id.edit2);
        EditText workupdateEditText = findViewById(R.id.edit4);
        EditText remarksEditText = findViewById(R.id.edit5);


        // **
        String RequestorNidno = RequestorNidnoEditText.getText().toString();
        String Requestorname = RequestornameEditText.getText().toString();
        String RequestorPinno = RequestorPinnoEditText.getText().toString();
        String Refname = RefnameEditText.getText().toString();
        String Reqdate = ReqdateEditText.getText().toString();
        String workupdate = workupdateEditText.getText().toString();
        String remarks = remarksEditText.getText().toString();
        // **
        Contact contact = new Contact();
        contact.setRequestorNidno(RequestorNidno);
        contact.setRequestorname(Requestorname);
        contact.setRequestorPinno(RequestorPinno);
        contact.setRefname(Refname);
        contact.setReqdate(Reqdate);
        contact.setworkupdate(workupdate);
        contact.setremarks(remarks);

        if (Requestorname.isEmpty() ||Refname.isEmpty()){
            Toast.makeText(this, "Please insert data in two mandatory fields!", Toast.LENGTH_SHORT).show();
        }

         else {
            // **
            contactViewModel = new ViewModelProvider(AddContactActivity.this).get(ContactViewModel.class);
            contactViewModel.insert(contact);
            // **
            Toast.makeText(this, "NID Request Information saved!", Toast.LENGTH_SHORT).show();
            onBackPressed();
        }

    }

    // ActionBar Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_contact_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_save) {
            // **
            addContactToDb();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
